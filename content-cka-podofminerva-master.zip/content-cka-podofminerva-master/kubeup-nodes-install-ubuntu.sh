sudo apt update -y

sleep 60

sudo apt install -y docker-ce=18.06.2~ce~3-0~ubuntu kubelet kubeadm kubectl